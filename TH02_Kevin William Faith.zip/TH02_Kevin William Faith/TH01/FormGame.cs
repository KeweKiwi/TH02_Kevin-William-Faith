﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01
{
    public partial class FormGame : Form
    {
        public List<string> listWords;
        string wordToGuess;
        string wordToGuess1;
        public FormGame()
        {
            InitializeComponent();
        }
        
       

        private void FormGame_Load(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int num = rnd.Next(listWords.Count);
            wordToGuess = listWords[num];
            wordToGuess1 = listWords[num];
        }

        private void checkWord(char c)
        {
            for (int i = 0; i < wordToGuess.Length; i++)
            {
                if (c == wordToGuess[i])
                {
                    if (i == 0)
                    {
                        lbl_one.Text = c.ToString().ToUpper();
                        lbl_1.Visible = false;
                    }
                    if (i == 1)
                    {
                        lbl_two.Text = c.ToString().ToUpper();
                        lbl_2.Visible = false;
                    }
                    if (i == 2)
                    {
                        lbl_three.Text = c.ToString().ToUpper();
                        lbl_3.Visible = false;
                    }
                    if (i == 3)
                    {
                        lbl_four.Text = c.ToString().ToUpper();
                        lbl_4.Visible = false;
                    }
                    if (i == 4)
                    {
                        lbl_five.Text = c.ToString().ToUpper();
                        lbl_5.Visible = false;
                    }

                }
            }
            checkWin();
        }

        private void checkWin()
        {
            string result = lbl_one.Text + lbl_two.Text + lbl_three.Text + lbl_four.Text + lbl_five.Text;
            if (wordToGuess.ToUpper() == result)
            {
                MessageBox.Show("CONGRATS");
                this.Close();
            }
        }

        private void btn_q_Click(object sender, EventArgs e)
        {
            checkWord('q');
        }
        private void btn_w_Click(object sender, EventArgs e)
        {
            checkWord('w');

        }

        private void btn_e_Click(object sender, EventArgs e)
        {
            checkWord('e');

        }

        private void btn_r_Click(object sender, EventArgs e)
        {
            checkWord('r');

        }

        private void btn_t_Click(object sender, EventArgs e)
        {
            checkWord('t');

        }

        private void btn_y_Click(object sender, EventArgs e)
        {
            checkWord('y');

        }

        private void btn_u_Click(object sender, EventArgs e)
        {
            checkWord('u');

        }

        private void btn_i_Click(object sender, EventArgs e)
        {
            checkWord('i');

        }

        private void btn_o_Click(object sender, EventArgs e)
        {
            checkWord('o');

        }

        private void btn_p_Click(object sender, EventArgs e)
        {
            checkWord('p');

        }

        private void btn_a_Click(object sender, EventArgs e)
        {
            checkWord('a');

        }

        private void btn_s_Click(object sender, EventArgs e)
        {
            checkWord('s');

        }

        private void btn_d_Click(object sender, EventArgs e)
        {
            checkWord('d');

        }

        private void btn_f_Click(object sender, EventArgs e)
        {
            checkWord('f');

        }

        private void btn_g_Click(object sender, EventArgs e)
        {
            checkWord('g');

        }

        private void btn_h_Click(object sender, EventArgs e)
        {
            checkWord('h');

        }

        private void btn_j_Click(object sender, EventArgs e)
        {
            checkWord('j');

        }

        private void btn_k_Click(object sender, EventArgs e)
        {
            checkWord('k');

        }

        private void btn_l_Click(object sender, EventArgs e)
        {
            checkWord('l');

        }

        private void btn_z_Click(object sender, EventArgs e)
        {
            checkWord('z');

        }

        private void btn_x_Click(object sender, EventArgs e)
        {
            checkWord('x');

        }

        private void btn_c_Click(object sender, EventArgs e)
        {
            checkWord('c');

        }

        private void btn_v_Click(object sender, EventArgs e)
        {
            checkWord('v');

        }

        private void btn_b_Click(object sender, EventArgs e)
        {
            checkWord('b');

        }

        private void btn_n_Click(object sender, EventArgs e)
        {
            checkWord('n');

        }

        private void btn_m_Click(object sender, EventArgs e)
        {
            checkWord('m');

        }
    }
}
