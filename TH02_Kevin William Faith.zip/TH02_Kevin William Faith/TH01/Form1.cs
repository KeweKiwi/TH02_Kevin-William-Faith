﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            List<string> words = new List<string>();
            int duplicate = 0;

            if (tb_kal1.Text.Length == 5 && tb_kal2.Text.Length == 5 && tb_kal3.Text.Length == 5 && tb_kal4.Text.Length == 5 && tb_kal5.Text.Length == 5)
            {
                if (tb_kal1.Text != "" && tb_kal2.Text != "" && tb_kal3.Text != "" && tb_kal4.Text != "" && tb_kal5.Text != "")
                {
                    words.Add(tb_kal1.Text);
                    words.Add(tb_kal2.Text);
                    words.Add(tb_kal3.Text);
                    words.Add(tb_kal4.Text);
                    words.Add(tb_kal5.Text);
                    string checkKata = check(words);

                    foreach(string word1 in words)
                    {
                        foreach(string word2 in words)
                        {
                            if (word1 == word2)
                            {
                                duplicate++;
                            }
                        }
                    }
                        
                    if (duplicate <= words.Count)
                    {
                        if (checkKata == "")
                        {
                            FormGame formGame = new FormGame();
                            formGame.Owner = this;
                            formGame.listWords = words;
                            formGame.ShowDialog();
                        }
                        else
                        {
                            MessageBox.Show("Kata " + checkKata + " tidak boleh mengandung angka!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Pastikan Semua Inputan Tidak Sama!!");

                    }

                }
                else
                {
                    MessageBox.Show("Pastikan Semua Inputan Terisi!!");
                }
            }
            else
            {
                MessageBox.Show("Pastikan Semua Inputan Mengandung 5 Huruf!!");
            }



        }

        private string check(List<string> word)
        {
            string kata = "";
            foreach(string s in word)
            {
                foreach(char c in s)
                {
                    if (char.IsDigit(c))
                    {
                        kata += s;
                        break;
                    }
                }
            }
            return kata;
        }

        
    }
}
